import java.util.Arrays;

public class Zadatak1 {
    public static void main(String[] args) {
        String[] niz1 = {"Midna", "peach", "LUCINA"};
        boolean rez = princezaUZamku(niz1);
        System.out.println(rez);
    }


    public static boolean princezaUZamku(String[] niz) {
        for (int i = 0; i < niz.length; i++) {
            niz[i] = niz[i].toLowerCase();
        }
        return Arrays.asList(niz).contains("peach") || Arrays.asList(niz).contains("daisy");
    }
}
